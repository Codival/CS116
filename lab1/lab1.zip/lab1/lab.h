#ifndef LAB_H
#define LAB_H

#include <iostream>
#include <string>
#include <iomanip>
#include <ctime>
#include <limits>

void printMeFirst(std::string name, std::string courseInfo);
void menu();
void convertTime();
void convertCtoF();
void convertFtoC();

#endif
