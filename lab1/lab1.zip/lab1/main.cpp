/*
 *Purpose:
 * Calls the printMeFirst Function and the Menu Function 
 * 
 * @author Amuldeep Dhillon
 * @version 1.0 2/3/2017
 * 
 * @param - none
 * @return - 0
*/
#include "lab.h"
int main (){
	printMeFirst("Amuldeep Dhillon", "Lab 1: CS 116-02 Thursdays");
	menu();
	return 0;
}
