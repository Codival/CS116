#ifndef LAB_H
#define LAB_H

#include <iostream>
#include <string>
#include <iomanip>
#include <ctime>
#include "account.h"
#include "bank.h"
void printMeFirst(std::string name, std::string courseInfo);
const double penalty = 5;
#endif
