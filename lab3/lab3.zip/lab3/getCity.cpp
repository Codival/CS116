#include "wine.h"

/*
 * Purpose:return the Winery's City
 * 
 * @author: Amuldeep Dhillon
 * @version: 1.0 3/7/2016
 * 
 * @param:none
 * 
 * @return:the Winery's City
*/


string Address::getCity(){
	return city;
}
