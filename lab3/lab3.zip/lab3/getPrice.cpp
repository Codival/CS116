#include "wine.h"

/*
 * Purpose:retrieve wine's price
 * 
 * @author: Amuldeep Dhillon
 * @version: 1.0 3/7/2017
 * 
 * @param:none
 * 
 * @return:
*/


double Wine::getPrice(){
	return winePrice;
}
