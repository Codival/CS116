#include "wine.h"
/*
 * Purpose:get the wine's rating
 * 
 * @author: Amuldeep Dhillon
 * @version: 1.0 3/7/2016
 * 
 * @param:none
 * 
 * @return:wine's rating
*/

int Wine::getRating () {
	return wineRating;
}
