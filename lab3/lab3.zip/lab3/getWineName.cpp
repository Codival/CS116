#include "wine.h"

/*
 * Purpose:retrive wine's name
 * 
 * @author: Amuldeep Dhillon
 * @version: 1.0 3/7/2016
 * 
 * @param:none
 * 
 * @return:the wine's name
*/


string Wine::getWineName(){
	return wineName;
}
