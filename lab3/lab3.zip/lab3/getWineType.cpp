#include "wine.h"

/*
 * Purpose:retrieve Wine's type
 * 
 * @author: Amuldeep Dhillon
 * @version: 1.0 3/7/2016
 * 
 * @param:none
 * 
 * @return:the wine's type
*/


string Wine::getWineType(){
	return wineType;
}
