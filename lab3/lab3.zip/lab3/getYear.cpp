#include "wine.h"

/*
 * Purpose:retrieve the wine's vintage
 * 
 * @author: Amuldeep Dhillon
 * @version: 1.0 3/7/2016
 * 
 * @param:none
 * 
 * @return:the wine's vintage
*/


int Wine::getYear(){
	return wineYear;
}
