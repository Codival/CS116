/*#include "wine.h"

void printMoreInfo(Wine p){
	cout << left << setw(30) << setfill(' ') << p.wineName << setw(15) 
	<< setfill(' ') << p.wineType << setw(15) << setfill(' ') << 
	p.wineYear << setw(15) << setfill(' ') << p.wineRating << setw(15) 
	<< setfill(' ') << p.winePrice << setw(15) << setfill(' ') 
	<< p.paddress->getCity() <<endl;

}
*/
