#include "wine.h"

/*
 * Purpose:Set Winery's City
 * 
 * @author: Amuldeep Dhillon
 * @version: 1.0 3/7/2016
 * 
 * @param:Name of the Winery's City
 * 
 * @return:none
*/


void Address::setCity (string c){
	city = c;
}
