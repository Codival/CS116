The winelist.txt contains sample wine information.  Each field is separated by ;


wine name; wine type; vitage; rating; price; winery name; winery address; winery city; winery state; winery zipcode
