/*
 *Contains the class Checking which inherits Account
 * @author Amuldeep Dhillon
 * @version 1.0 4/6/2017
 * 
*/
#ifndef CHECKING_H
#define CHECKING_H

class Checking:public Account
{
};


#endif
