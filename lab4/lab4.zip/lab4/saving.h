/*
 *Contains the class Saving which inherits Account
 * @author Amuldeep Dhillon
 * @version 1.0 4/6/2017
 * 
*/
#ifndef SAVING_H
#define SAVING_H

class Saving:public Account
{
};


#endif
