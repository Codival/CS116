/*
 *Purpose:set the Name of the Wine
 * 
 * @author Amuldeep Dhillon
 * @version 1.0 5/6/2017
 * 
 * @param wine_name = the name we want the wine to have
 * @return - none
*/
#include "lab.h"

void Wine::setName(string wine_name){
	wineName = wine_name;
}
