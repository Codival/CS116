/*
 *Purpose:set the Price of the Wine
 * 
 * @author Amuldeep Dhillon
 * @version 1.0 5/6/2017
 * 
 * @param wine_price = the price we want the wine to have
 * @return - none
*/
#include "lab.h"

void Wine::setPrice(double wine_price){
	winePrice = wine_price;
}

