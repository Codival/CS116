/*
 *Purpose:set the Type of the Wine
 * 
 * @author Amuldeep Dhillon
 * @version 1.0 5/6/2017
 * 
 * @param wine_type = the type we want the wine to have
 * @return - none
*/
#include "lab.h"

void Wine::setType(string wine_type){
	wineType = wine_type;
}

