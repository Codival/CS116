/*
 *Purpose:set the Vintage of the Wine
 * 
 * @author Amuldeep Dhillon
 * @version 1.0 5/6/2017
 * 
 * @param wine_vintage = the vintage we want the wine to have
 * @return - none
*/
#include "lab.h"

void Wine::setVintage(int wine_year){
	wineYear = wine_year;
}

